
public class App {
	public static void main(String args[]) {
		Library lib = new Library("､ｻ");
		lib.registerOneBorrower("ﾀﾌﾁ�", 2017315023);
		lib.registerOneBook("a", "b", 1);
		
		System.out.println("--------ｴ�ﾃ箍｡ｴﾉﾇﾑﾃ･-------");
		lib.displayBooksForLoan();
		System.out.println("---------ｴ�ﾃ篌ﾒｰ｡ｴﾉﾇﾑﾃ･------");
		
		lib.displayBooksOnLoan();
		lib.lendOneBook(1, 2017315023);	
		System.out.println("------------ｴ�ﾃ箍｡ｴﾉ---");
		lib.displayBooksForLoan();
		System.out.println("--------------ｴ�ﾃ篌ﾒｰ｡ｴﾉ-");
		lib.displayBooksOnLoan();
		lib.returnOneBook(1);
		System.out.println("------------ｴ�ﾃ箍｡ｴﾉ---");
		lib.displayBooksForLoan();
		System.out.println("--------------ｴ�ﾃ篌ﾒｰ｡ｴﾉ-");
		lib.displayBooksOnLoan();
		
		//////ｼ､ﾇﾊｿ�!!!!!!!!!
	}
}
