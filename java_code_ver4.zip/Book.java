import java.util.LinkedList;

public class Book{
	private static String title;
	private static String author;
	private static int catalogueNumber;
	private Borrower borrower;
	private static LinkedList<Borrower> borrowBook;
	
	public Book(String title, String author, int catalogueNumber) {
		this.title = title;
		this.author = author;
		this.catalogueNumber = catalogueNumber;
	}
	
	
	public String getTitle() {
		return title;
	}
	public String getAuthor() {
		return author;
	}
	public int getCatalogueNumber() {
		return catalogueNumber;
	}
	public void attachBorrower(Borrower borrower) {
		borrowBook = new LinkedList<Borrower>();
		this.borrower=borrower;
	}
	public void detachBorrower() {
		borrowBook.remove();
		this.borrower=null;
	}
	public Borrower getBorrower() {
		return borrower;
	}
	public void setBorrower(Borrower borrower) {
		this.borrower = borrower;
	}
	
	public static void display() {
		System.out.println("책의 제목 :" + title);
		System.out.println("책의 작가 :" + author);
		System.out.println("책의 분류번호 :" + catalogueNumber);
	}
}
